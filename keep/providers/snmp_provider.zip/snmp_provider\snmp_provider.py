"""
SNMP Provider is a class that allows Keep to receive SNMP traps/events as alerts.
"""

from keep.api.models.alert import AlertDto, AlertSeverity, AlertStatus
from keep.contextmanager.contextmanager import ContextManager
from keep.providers.base.base_provider import BaseProvider
from keep.providers.models.provider_config import ProviderConfig


class SnmpProvider(BaseProvider):
    """Receive SNMP traps/events as alerts in Keep."""

    webhook_description = "SNMP trap receiver endpoint"
    webhook_template = ""
    webhook_markdown = """
To send SNMP traps to Keep, configure your SNMP trap sender to forward events to the Keep webhook:

1. Configure your SNMP manager or trap forwarder (e.g., snmptrapd) to convert traps to HTTP POST.
2. Use a tool like `snmptt` (SNMP Trap Translator) or a custom script to forward traps as JSON.
3. POST the JSON payload to: {keep_webhook_api_url}
4. Include the header `x-api-key: {api_key}` for authentication.

**Expected JSON payload format:**
```json
{
    "oid": "1.3.6.1.4.1.9.9.13.1.3.1.3",
    "trap_type": "linkDown",
    "agent_address": "192.168.1.1",
    "enterprise": "1.3.6.1.4.1.9",
    "generic_trap": 2,
    "specific_trap": 0,
    "uptime": 123456,
    "varbinds": {
        "1.3.6.1.2.1.2.2.1.1": "1",
        "1.3.6.1.2.1.2.2.1.2": "GigabitEthernet0/1"
    },
    "message": "Interface GigabitEthernet0/1 is down",
    "severity": "critical"
}
```

**Using snmptrapd:**
Configure `/etc/snmp/snmptrapd.conf` to execute a script that forwards traps to Keep.
"""

    # Map SNMP severity strings to Keep AlertSeverity
    SEVERITIES_MAP = {
        "emergency": AlertSeverity.CRITICAL,
        "alert": AlertSeverity.CRITICAL,
        "critical": AlertSeverity.CRITICAL,
        "error": AlertSeverity.HIGH,
        "warning": AlertSeverity.WARNING,
        "notice": AlertSeverity.INFO,
        "info": AlertSeverity.INFO,
        "informational": AlertSeverity.INFO,
        "debug": AlertSeverity.LOW,
    }

    # Map generic trap types to status
    GENERIC_TRAP_MAP = {
        0: "coldStart",
        1: "warmStart",
        2: "linkDown",
        3: "linkUp",
        4: "authenticationFailure",
        5: "egpNeighborLoss",
        6: "enterpriseSpecific",
    }

    PROVIDER_DISPLAY_NAME = "SNMP"
    PROVIDER_TAGS = ["alert"]
    PROVIDER_CATEGORY = ["Monitoring"]

    def __init__(
        self, context_manager: ContextManager, provider_id: str, config: ProviderConfig
    ):
        super().__init__(context_manager, provider_id, config)

    def validate_config(self):
        """
        No configuration required for webhook-based SNMP trap receiver.
        """
        pass

    def dispose(self):
        """
        No resources to dispose.
        """
        pass

    @staticmethod
    def _format_alert(
        event: dict, provider_instance: "BaseProvider" = None
    ) -> AlertDto:
        """
        Format an incoming SNMP trap event into an AlertDto.

        Args:
            event (dict): The SNMP trap data as JSON.
            provider_instance: Optional provider instance for context.

        Returns:
            AlertDto: The formatted alert.
        """
        # Extract OID as the alert name/identifier
        oid = event.get("oid", "unknown")
        trap_type = event.get("trap_type", "")
        generic_trap = event.get("generic_trap")
        
        # Determine trap type name
        if trap_type:
            name = trap_type
        elif generic_trap is not None:
            name = SnmpProvider.GENERIC_TRAP_MAP.get(generic_trap, f"trap_{generic_trap}")
        else:
            name = f"snmp_trap_{oid}"

        # Extract agent/host address
        agent_address = event.get("agent_address", event.get("host", "unknown"))

        # Build message from event data
        message = event.get("message", "")
        if not message:
            varbinds = event.get("varbinds", {})
            if varbinds:
                message = f"SNMP Trap: {name} from {agent_address} - {varbinds}"
            else:
                message = f"SNMP Trap: {name} from {agent_address}"

        # Map severity
        severity_str = event.get("severity", "info").lower()
        severity = SnmpProvider.SEVERITIES_MAP.get(severity_str, AlertSeverity.INFO)

        # Determine status based on trap type
        status = AlertStatus.FIRING
        if trap_type in ["linkUp", "coldStart", "warmStart"]:
            status = AlertStatus.RESOLVED
        elif event.get("status"):
            status_str = event.get("status", "").lower()
            if status_str in ["resolved", "ok", "up", "clear"]:
                status = AlertStatus.RESOLVED

        # Create the AlertDto
        alert = AlertDto(
            id=event.get("id", f"{agent_address}_{oid}_{event.get('uptime', '')}"),
            name=name,
            host=agent_address,
            message=message,
            severity=severity,
            status=status,
            source=["snmp"],
            # SNMP-specific fields
            oid=oid,
            enterprise=event.get("enterprise"),
            generic_trap=generic_trap,
            specific_trap=event.get("specific_trap"),
            uptime=event.get("uptime"),
            varbinds=event.get("varbinds", {}),
            agent_address=agent_address,
        )

        return alert


if __name__ == "__main__":
    # Test the provider
    test_event = {
        "oid": "1.3.6.1.4.1.9.9.13.1.3.1.3",
        "trap_type": "linkDown",
        "agent_address": "192.168.1.1",
        "generic_trap": 2,
        "severity": "critical",
        "message": "Interface GigabitEthernet0/1 is down",
    }
    alert = SnmpProvider._format_alert(test_event)
    print(f"Alert: {alert}")
