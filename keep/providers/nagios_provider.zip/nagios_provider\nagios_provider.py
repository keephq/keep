"""
Nagios Provider for Keep

Nagios is a popular open-source monitoring system that monitors hosts, services,
and network infrastructure. This provider receives Nagios alerts via webhook.
"""

import dataclasses
from typing import Optional
from keep.api.models.alert import AlertDto, AlertSeverity, AlertStatus
from keep.contextmanager.contextmanager import ContextManager
from keep.providers.base.base_provider import BaseProvider
from keep.providers.models.provider_config import ProviderConfig


@dataclasses.dataclass
class NagiosProviderAuthConfig:
    """Nagios provider auth configuration (webhook-based, no auth required)"""
    pass


class NagiosProvider(BaseProvider):
    """
    Nagios Provider - Receives alerts from Nagios monitoring system via webhook.
    
    Nagios can send notifications via various methods. This provider expects
    alerts to be forwarded as JSON via HTTP POST to Keep's webhook endpoint.
    """

    PROVIDER_DISPLAY_NAME = "Nagios"
    PROVIDER_CATEGORY = ["Monitoring"]

    # Nagios state to Keep severity mapping
    # Nagios uses: OK=0, WARNING=1, CRITICAL=2, UNKNOWN=3 for services
    # For hosts: UP=0, DOWN=1, UNREACHABLE=2
    SEVERITIES_MAP = {
        "ok": AlertSeverity.INFO,
        "up": AlertSeverity.INFO,
        "warning": AlertSeverity.WARNING,
        "critical": AlertSeverity.CRITICAL,
        "down": AlertSeverity.CRITICAL,
        "unknown": AlertSeverity.WARNING,
        "unreachable": AlertSeverity.HIGH,
        "0": AlertSeverity.INFO,  # OK/UP
        "1": AlertSeverity.WARNING,  # WARNING/DOWN
        "2": AlertSeverity.CRITICAL,  # CRITICAL/UNREACHABLE
        "3": AlertSeverity.WARNING,  # UNKNOWN
    }

    # Nagios state to Keep status mapping
    STATUS_MAP = {
        "ok": AlertStatus.RESOLVED,
        "up": AlertStatus.RESOLVED,
        "warning": AlertStatus.FIRING,
        "critical": AlertStatus.FIRING,
        "down": AlertStatus.FIRING,
        "unknown": AlertStatus.FIRING,
        "unreachable": AlertStatus.FIRING,
        "recovery": AlertStatus.RESOLVED,
        "problem": AlertStatus.FIRING,
        "acknowledgement": AlertStatus.ACKNOWLEDGED,
    }

    # Nagios notification types
    NOTIFICATION_TYPES = {
        "PROBLEM": AlertStatus.FIRING,
        "RECOVERY": AlertStatus.RESOLVED,
        "ACKNOWLEDGEMENT": AlertStatus.ACKNOWLEDGED,
        "FLAPPINGSTART": AlertStatus.FIRING,
        "FLAPPINGSTOP": AlertStatus.RESOLVED,
        "FLAPPINGDISABLED": AlertStatus.RESOLVED,
        "DOWNTIMESTART": AlertStatus.SUPPRESSED,
        "DOWNTIMEEND": AlertStatus.RESOLVED,
        "DOWNTIMECANCELLED": AlertStatus.RESOLVED,
    }

    PROVIDER_SCOPES = []

    def __init__(
        self,
        context_manager: ContextManager,
        provider_id: str,
        config: ProviderConfig,
    ):
        super().__init__(context_manager, provider_id, config)

    def validate_config(self):
        """No configuration needed for webhook-based provider"""
        pass

    def dispose(self):
        """Nothing to dispose"""
        pass

    def validate_scopes(self):
        """No scopes to validate for webhook provider"""
        return {}

    @staticmethod
    def _format_alert(
        event: dict, provider_instance: "BaseProvider" = None
    ) -> AlertDto:
        """
        Format a Nagios event into a Keep AlertDto.
        
        Expected Nagios webhook payload fields:
        - host_name: The host being monitored
        - service_description: The service being monitored (optional, for service alerts)
        - state: Current state (OK, WARNING, CRITICAL, UNKNOWN, UP, DOWN, UNREACHABLE)
        - output: Plugin output message
        - notification_type: Type of notification (PROBLEM, RECOVERY, etc.)
        - timestamp or last_check: When the event occurred
        - attempt: Current check attempt
        - max_attempts: Maximum check attempts
        - state_type: SOFT or HARD
        """
        
        # Extract host and service info
        host_name = event.get("host_name", event.get("hostname", "unknown"))
        service_description = event.get("service_description", event.get("service", ""))
        
        # Determine if this is a host or service alert
        is_service_alert = bool(service_description)
        
        # Build alert name
        if is_service_alert:
            name = f"{host_name}/{service_description}"
        else:
            name = f"{host_name} Host Alert"
        
        # Get state and map to severity
        state = str(event.get("state", event.get("service_state", event.get("host_state", "unknown")))).lower()
        severity = NagiosProvider.SEVERITIES_MAP.get(state, AlertSeverity.WARNING)
        
        # Get notification type and map to status
        notification_type = event.get("notification_type", event.get("type", "")).upper()
        if notification_type in NagiosProvider.NOTIFICATION_TYPES:
            status = NagiosProvider.NOTIFICATION_TYPES[notification_type]
        else:
            status = NagiosProvider.STATUS_MAP.get(state, AlertStatus.FIRING)
        
        # Get output/message
        output = event.get("output", event.get("plugin_output", event.get("message", "")))
        long_output = event.get("long_output", event.get("long_plugin_output", ""))
        
        if long_output:
            message = f"{output}\n{long_output}"
        else:
            message = output
        
        # Build unique alert ID
        alert_id = event.get("id", f"nagios-{host_name}-{service_description or 'host'}-{event.get('timestamp', '')}")
        
        # Create AlertDto
        alert = AlertDto(
            id=alert_id,
            name=name,
            severity=severity,
            status=status,
            message=message,
            description=output,
            source=["nagios"],
            host=host_name,
            service=service_description if is_service_alert else None,
            # Nagios-specific fields
            notification_type=notification_type,
            state=state,
            state_type=event.get("state_type", event.get("statetype", "")),
            attempt=event.get("attempt", event.get("current_attempt", "")),
            max_attempts=event.get("max_attempts", ""),
            last_check=event.get("last_check", event.get("timestamp", "")),
            next_check=event.get("next_check", ""),
            check_command=event.get("check_command", ""),
            contact_name=event.get("contact_name", ""),
            contact_email=event.get("contact_email", ""),
            contact_pager=event.get("contact_pager", ""),
            host_address=event.get("host_address", event.get("address", "")),
            host_alias=event.get("host_alias", ""),
            host_groups=event.get("host_groups", event.get("hostgroups", "")),
            service_groups=event.get("service_groups", event.get("servicegroups", "")),
            notes=event.get("notes", ""),
            notes_url=event.get("notes_url", ""),
            action_url=event.get("action_url", ""),
            event_id=event.get("event_id", ""),
            problem_id=event.get("problem_id", ""),
            is_flapping=event.get("is_flapping", False),
            downtime_depth=event.get("downtime_depth", 0),
            percent_state_change=event.get("percent_state_change", ""),
            latency=event.get("latency", ""),
            execution_time=event.get("execution_time", ""),
        )
        
        return alert

    webhook_description = "Receive alerts from Nagios monitoring system"
    webhook_template = ""
    webhook_markdown = """
## Nagios Webhook Integration

To send Nagios alerts to Keep, configure a custom notification command that forwards alerts as JSON via HTTP POST.

### Step 1: Create a notification script

Create a script (e.g., `/usr/local/nagios/libexec/notify_keep.sh`):

```bash
#!/bin/bash

KEEP_WEBHOOK_URL="{{keep_webhook_api_url}}"
API_KEY="{{api_key}}"

# Build JSON payload
JSON_PAYLOAD=$(cat <<EOF
{
    "host_name": "$NAGIOS_HOSTNAME",
    "host_address": "$NAGIOS_HOSTADDRESS",
    "host_state": "$NAGIOS_HOSTSTATE",
    "host_alias": "$NAGIOS_HOSTALIAS",
    "service_description": "$NAGIOS_SERVICEDESC",
    "state": "$NAGIOS_SERVICESTATE",
    "output": "$NAGIOS_SERVICEOUTPUT",
    "long_output": "$NAGIOS_LONGSERVICEOUTPUT",
    "notification_type": "$NAGIOS_NOTIFICATIONTYPE",
    "state_type": "$NAGIOS_STATETYPE",
    "attempt": "$NAGIOS_SERVICEATTEMPT",
    "max_attempts": "$NAGIOS_MAXSERVICEATTEMPTS",
    "last_check": "$NAGIOS_LASTSERVICECHECK",
    "timestamp": "$(date +%s)",
    "contact_name": "$NAGIOS_CONTACTNAME",
    "contact_email": "$NAGIOS_CONTACTEMAIL"
}
EOF
)

# Send to Keep
curl -s -X POST "$KEEP_WEBHOOK_URL" \\
    -H "Content-Type: application/json" \\
    -H "X-API-KEY: $API_KEY" \\
    -d "$JSON_PAYLOAD"
```

### Step 2: Define notification commands in Nagios

Add to your `commands.cfg`:

```
define command {
    command_name    notify-service-keep
    command_line    /usr/local/nagios/libexec/notify_keep.sh
}

define command {
    command_name    notify-host-keep
    command_line    /usr/local/nagios/libexec/notify_keep.sh
}
```

### Step 3: Configure contacts to use the commands

In your `contacts.cfg`:

```
define contact {
    contact_name                    keep-alerts
    alias                           Keep Alert Manager
    service_notification_commands   notify-service-keep
    host_notification_commands      notify-host-keep
    service_notification_period     24x7
    host_notification_period        24x7
    service_notification_options    w,u,c,r
    host_notification_options       d,u,r
}
```

### Step 4: Restart Nagios

```bash
sudo systemctl restart nagios
```

### Expected JSON payload

```json
{
    "host_name": "webserver01",
    "service_description": "HTTP",
    "state": "CRITICAL",
    "output": "HTTP CRITICAL - Connection refused",
    "notification_type": "PROBLEM",
    "state_type": "HARD",
    "attempt": "3",
    "max_attempts": "3",
    "timestamp": "1706400000"
}
```
"""
